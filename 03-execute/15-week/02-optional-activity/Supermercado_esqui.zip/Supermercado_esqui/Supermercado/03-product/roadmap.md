# roadmap

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Roadmap

### Fase 1

- Registro de ventas.
- Control de inventario.
- Alertas de stock mínimo.
- Gestión de cuentas por cobrar.
- Inicio de sesión.
- Gestión de usuarios.
- Cálculo automático del cambio.

### Fase 2

- Gestión de pedidos a proveedores.
- Reportes de ventas.
- Actualización de precios.

### Fase 3

- Historial de movimientos.
- Mejoras de rendimiento.
- Optimización y mantenimiento del sistema.