# product-backlog

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Product Backlog

| Prioridad | Historia de usuario |
|-----------|---------------------|
| Alta | Como cajero quiero registrar ventas para agilizar la atención al cliente y reducir errores. |
| Alta | Como administrador quiero controlar el inventario para conocer la disponibilidad de productos en tiempo real. |
| Alta | Como administrador quiero recibir alertas de stock mínimo para evitar el agotamiento de productos. |
| Alta | Como administrador quiero administrar usuarios para controlar el acceso al sistema según el rol. |
| Alta | Como cajero quiero registrar fiados para llevar el control de las cuentas por cobrar. |
| Media | Como administrador quiero gestionar pedidos a proveedores para organizar el abastecimiento del supermercado. |
| Media | Como administrador quiero consultar reportes para analizar las ventas y el inventario. |
| Media | Como administrador quiero actualizar precios de los productos cuando sea necesario. |
| Baja | Como administrador quiero consultar el historial de movimientos para realizar auditorías del sistema. |