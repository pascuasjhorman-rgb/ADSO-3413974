# deployment

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Despliegue

### Ambiente de ejecución

El sistema será una aplicación web accesible desde cualquier navegador con conexión a internet.

### Componentes desplegados

- Aplicación web.
- Base de datos.
- Servicio de autenticación.

### Usuarios del sistema

- Administrador.
- Cajero.

### Consideraciones

El sistema requiere conexión a internet para su funcionamiento y no contempla un modo de operación sin conexión.