# cross-cutting

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Aspectos transversales

### Seguridad

- Acceso mediante usuario y contraseña.
- Gestión de usuarios con roles de administrador y cajero.

### Rendimiento

- El tiempo de respuesta de las pantallas no deberá superar los tres segundos en condiciones normales.

### Usabilidad

- La interfaz deberá ser sencilla, intuitiva y fácil de utilizar para usuarios con poca experiencia tecnológica.

### Auditoría

- El sistema registrará el historial de movimientos realizados por los usuarios autorizados.

### Disponibilidad

- El sistema estará disponible durante el horario de funcionamiento del supermercado.