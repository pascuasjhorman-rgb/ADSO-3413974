# entities-and-rules

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Entidades

### Producto
Representa cada artículo disponible para la venta, con información como nombre, categoría, precio y cantidad disponible.

### Inventario
Controla la existencia de los productos y genera alertas cuando se alcanza el stock mínimo.

### Venta
Registra las transacciones realizadas, incluyendo productos, cantidades, fecha, hora y total.

### Cliente
Persona que realiza compras en el supermercado y puede tener compras a crédito.

### Cuenta por cobrar
Registra los fiados realizados a los clientes y permite llevar el control de los pagos pendientes.

### Pedido
Representa las solicitudes de productos realizadas a los proveedores.

### Proveedor
Empresa o persona que suministra los productos al supermercado.

### Usuario
Persona autorizada para acceder al sistema según su rol (administrador o cajero).

---

## Reglas de negocio

- No se podrá registrar una venta si un producto no tiene existencias suficientes.
- El inventario deberá actualizarse automáticamente después de cada venta.
- Cuando un producto alcance el stock mínimo, el sistema deberá generar una alerta.
- Los fiados solo podrán registrarse para clientes identificados.
- Cada pedido deberá asociarse a un proveedor.
- Solo el administrador podrá gestionar usuarios y modificar información sensible.