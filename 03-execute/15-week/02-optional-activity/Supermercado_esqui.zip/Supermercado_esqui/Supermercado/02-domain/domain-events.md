# domain-events

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Eventos de dominio

- Inicio de sesión de un usuario.
- Registro de una venta.
- Actualización automática del inventario.
- Generación de una alerta por stock mínimo.
- Registro de un cliente.
- Creación de una cuenta por cobrar.
- Registro de un pedido a proveedor.
- Actualización del estado de un pedido.
- Pago de una cuenta por cobrar.
- Generación de reportes de ventas e inventario.