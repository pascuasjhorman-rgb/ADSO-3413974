# domain-map

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Mapa de dominio

El dominio del sistema corresponde a la gestión integral del Supermercado La Esquina, permitiendo administrar las operaciones comerciales y el control de la información del negocio.

### Entidades principales

- Producto
- Inventario
- Venta
- Cliente
- Cuenta por cobrar (Fiado)
- Pedido
- Proveedor
- Usuario

### Relación entre entidades

- Un cliente puede realizar una o varias ventas.
- Una venta está conformada por uno o varios productos.
- Cada producto pertenece al inventario.
- Un cliente puede tener una o varias cuentas por cobrar.
- Un pedido se realiza a un proveedor.
- Un usuario registra ventas, pedidos y movimientos según su rol.