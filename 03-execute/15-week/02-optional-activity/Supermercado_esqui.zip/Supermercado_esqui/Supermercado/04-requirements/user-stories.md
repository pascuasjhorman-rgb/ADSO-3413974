# user-stories

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Historias de usuario

### HU-01
**Como** cajero  
**Quiero** registrar una venta  
**Para** atender rápidamente a los clientes y mantener actualizado el inventario.

---

### HU-02
**Como** administrador  
**Quiero** administrar el inventario  
**Para** conocer la disponibilidad de los productos.

---

### HU-03
**Como** administrador  
**Quiero** recibir alertas de stock mínimo  
**Para** evitar que se agoten los productos.

---

### HU-04
**Como** administrador  
**Quiero** registrar los fiados de los clientes  
**Para** controlar las cuentas por cobrar.

---

### HU-05
**Como** administrador  
**Quiero** administrar usuarios  
**Para** controlar el acceso al sistema según el rol.

---

### HU-06
**Como** administrador  
**Quiero** gestionar pedidos a proveedores  
**Para** mantener abastecido el supermercado.

---

### HU-07
**Como** administrador  
**Quiero** consultar reportes de ventas e inventario  
**Para** apoyar la toma de decisiones.