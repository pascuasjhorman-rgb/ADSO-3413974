# functional

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Requisitos funcionales

### RF-01
El sistema debe registrar las ventas con fecha, hora, productos, cantidades y cálculo automático del total.

### RF-02
El sistema debe gestionar el inventario, permitiendo registrar, consultar y actualizar productos en tiempo real.

### RF-03
El sistema debe generar alertas cuando un producto alcance el stock mínimo configurado.

### RF-04
El sistema debe registrar y administrar las cuentas por cobrar (fiados) de los clientes.

### RF-05
El sistema debe permitir el inicio de sesión mediante usuario y contraseña.

### RF-06
El sistema debe gestionar usuarios con roles de administrador y cajero.

### RF-07
El sistema debe calcular automáticamente el cambio durante una venta.

### RF-08
El sistema debe registrar y controlar los pedidos realizados a los proveedores.

### RF-09
El sistema debe generar reportes de ventas e inventario por períodos de tiempo.

### RF-10
El sistema debe permitir actualizar los precios de los productos.

### RF-11
El sistema debe registrar el historial de movimientos realizados por los usuarios.