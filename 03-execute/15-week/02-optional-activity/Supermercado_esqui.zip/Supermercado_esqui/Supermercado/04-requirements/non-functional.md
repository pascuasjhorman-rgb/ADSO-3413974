# non-functional

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Requisitos no funcionales

### RNF-01 Usabilidad

La interfaz debe ser intuitiva, con botones claros y de fácil comprensión para usuarios con poca experiencia en el uso de computadores.

### RNF-02 Compatibilidad

El sistema debe funcionar correctamente en los navegadores Google Chrome, Mozilla Firefox y Microsoft Edge.

### RNF-03 Rendimiento

El tiempo de respuesta de cualquier pantalla no deberá superar los tres segundos en condiciones normales de operación.