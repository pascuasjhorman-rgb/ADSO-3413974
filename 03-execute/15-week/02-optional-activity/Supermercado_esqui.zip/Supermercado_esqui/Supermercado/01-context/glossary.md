# Glosario

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

# Glosario

| Término            | Definición                                                                          | Contexto                                                                       |
| ------------------ | ----------------------------------------------------------------------------------- | ------------------------------------------------------------------------------ |
| Sistema de Gestión | Aplicación desarrollada para administrar los procesos del supermercado.             | Se utiliza para controlar operaciones como ventas, inventario y reportes.      |
| Producto           | Artículo disponible para la venta dentro del inventario.                            | Puede ser un alimento, bebida u otro artículo comercializado en el negocio.    |
| Inventario         | Registro de todos los productos y sus cantidades disponibles.                       | Permite conocer qué productos hay en existencia y cuáles necesitan reposición. |
| Stock mínimo       | Cantidad mínima permitida antes de generar una alerta de reposición.                | Ayuda a evitar que un producto se agote en el almacén o en la tienda.          |
| Venta              | Operación mediante la cual se registra la compra de uno o varios productos.         | Se genera cuando un cliente adquiere productos en el punto de atención.        |
| Cliente            | Persona que realiza compras en el supermercado.                                     | Es quien adquiere productos y puede realizar pagos en efectivo o fiado.        |
| Fiado              | Venta realizada a crédito cuyo pago queda pendiente.                                | Se usa cuando el cliente no paga de inmediato y queda una deuda registrada.    |
| Usuario            | Persona autorizada para utilizar el sistema.                                        | Puede tener distintos roles según sus permisos dentro de la aplicación.        |
| Administrador      | Usuario con permisos para gestionar toda la información del sistema.                | Tiene acceso completo para configurar, supervisar y administrar el sistema.    |
| Cajero             | Usuario encargado de registrar las ventas y atender a los clientes.                 | Opera principalmente en la caja y registra las transacciones diarias.          |
| Reporte            | Documento generado por el sistema con información relevante para la administración. | Sirve para analizar ventas, inventario, clientes y otros datos importantes.    |
