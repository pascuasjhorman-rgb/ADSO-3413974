# Alcance

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## En alcance
- Gestión de productos.
- Control de inventario.
- Registro de ventas.
- Administración de clientes.
- Gestión de cuentas por cobrar (fiados).
- Administración de usuarios.
- Generación de reportes básicos.

## Fuera de alcance
- Facturación electrónica.
- Compras en línea.
- Aplicación móvil.
- Integración con sistemas contables externos.
- Pasarelas de pago electrónicas.

## Supuestos
- Los usuarios recibirán capacitación para utilizar el sistema.
- La información inicial de productos y clientes será registrada correctamente.
- El sistema contará con acceso a una base de datos para almacenar la información. 
  
## Restricciones
- El sistema será utilizado únicamente por el Supermercado La Esquina.
- Su funcionamiento dependerá de un equipo con acceso a la red local.
- Las funcionalidades implementadas corresponden únicamente a los requisitos definidos en el proyecto.
