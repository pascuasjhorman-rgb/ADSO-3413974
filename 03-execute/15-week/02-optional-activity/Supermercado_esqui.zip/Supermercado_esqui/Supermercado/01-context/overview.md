# Overview

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir



## Contexto

El Supermercado La Esquina es un negocio familiar ubicado en el barrio El Centro de Neiva, Huila, con más de diez años de funcionamiento. Actualmente, sus procesos de ventas, inventario, cuentas por cobrar y pedidos a proveedores se realizan de forma manual, lo que genera demoras, errores y dificultades para administrar la información.

Con el desarrollo de un sistema web se busca digitalizar estos procesos, mejorar el control de las operaciones y facilitar la toma de decisiones mediante información organizada y disponible en tiempo real.



## Problema

La gestión manual del supermercado ocasiona falta de control del inventario, errores en el registro de ventas, desorganización de las cuentas por cobrar, ausencia de seguimiento a los pedidos y dificultad para obtener reportes del negocio.

Estas situaciones afectan la atención al cliente y limitan la administración eficiente del supermercado.


## Lista de objetivos principales

- Digitalizar el registro de ventas del supermercado.
- Controlar el inventario en tiempo real.
- Administrar las cuentas por cobrar (fiados).
- Gestionar los pedidos realizados a proveedores.
- Generar reportes que apoyen la toma de decisiones.
- Mejorar la organización y eficiencia de los procesos administrativos.


## Referencias

- SRS v1.0 – Sistema de Gestión Supermercado La Esquina.
- Servicio Nacional de Aprendizaje (SENA).
- IEEE 830 - Software Requirements Specification.