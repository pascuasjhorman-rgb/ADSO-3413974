# non-functional

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Requisitos no funcionales

### Rendimiento
- El sistema debe responder en menos de 3 segundos.

### Seguridad
- Solo los usuarios autorizados podrán acceder al sistema.
- Las contraseñas deberán almacenarse de forma segura.

### Disponibilidad
- El sistema deberá estar disponible durante el horario de atención del supermercado.

### Usabilidad
- La interfaz debe ser sencilla e intuitiva para los usuarios.

### Mantenibilidad
- El código deberá estar organizado para facilitar futuras mejoras.