# user-stories

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Historias de usuario

### HU-01
**Como** administrador  
**Quiero** registrar productos  
**Para** mantener actualizado el inventario.

---

### HU-02
**Como** cajero  
**Quiero** registrar ventas  
**Para** controlar las transacciones realizadas.

---

### HU-03
**Como** administrador  
**Quiero** administrar clientes  
**Para** llevar el control de sus compras.

---

### HU-04
**Como** administrador  
**Quiero** registrar los fiados  
**Para** controlar las cuentas por cobrar.

---

### HU-05
**Como** administrador  
**Quiero** generar reportes  
**Para** conocer el estado del negocio.
