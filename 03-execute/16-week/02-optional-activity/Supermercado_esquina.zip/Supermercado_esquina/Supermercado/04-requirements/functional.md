# functional

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Requisitos funcionales

### RF-01
El sistema debe permitir registrar, editar y eliminar productos.

### RF-02
El sistema debe controlar el inventario de los productos.

### RF-03
El sistema debe registrar las ventas realizadas.

### RF-04
El sistema debe administrar la información de los clientes.

### RF-05
El sistema debe registrar las ventas a crédito (fiados).

### RF-06
El sistema debe generar reportes de ventas e inventario.

### RF-07
El sistema debe permitir el inicio de sesión de usuarios autorizados.