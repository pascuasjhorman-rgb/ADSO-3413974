# entities-and-rules

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Entidades

### Producto
Representa cada artículo disponible para la venta.

### Cliente
Persona que realiza compras en el supermercado.

### Venta
Registro de una compra realizada por un cliente.

### Inventario
Controla la cantidad disponible de cada producto.

### Usuario
Persona autorizada para utilizar el sistema.

### Cuenta por cobrar
Registro de las ventas realizadas a crédito.

---

## Reglas de negocio

- No se puede vender un producto sin existencias.
- Cada venta debe quedar registrada en el sistema.
- El inventario se actualiza automáticamente después de cada venta.
- Solo los usuarios autorizados pueden acceder al sistema.
- Los fiados deben asociarse a un cliente registrado.