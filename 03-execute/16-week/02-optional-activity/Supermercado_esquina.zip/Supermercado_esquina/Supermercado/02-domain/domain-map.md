# domain-map

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Mapa de dominio

El dominio del sistema corresponde a la administración de las operaciones del Supermercado La Esquina.

### Entidades principales

- Producto
- Inventario
- Cliente
- Venta
- Detalle de venta
- Usuario
- Cuenta por cobrar (Fiado)

### Relación entre entidades

- Un cliente puede realizar una o varias ventas.
- Una venta está compuesta por uno o varios productos.
- Cada producto pertenece al inventario.
- Un usuario registra las ventas.
- Un cliente puede tener cuentas por cobrar (fiados).