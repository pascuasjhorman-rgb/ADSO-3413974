# domain-events

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Eventos de dominio

- Registro de un nuevo producto.
- Actualización del inventario.
- Registro de una venta.
- Registro de un cliente.
- Creación de una cuenta por cobrar.
- Pago de una cuenta por cobrar.
- Generación de un reporte de ventas.