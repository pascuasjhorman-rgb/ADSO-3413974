# Overview

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Contexto institucional

El Supermercado La Esquina realiza procesos como el registro de ventas, el control del inventario y la gestión de fiados de forma manual, lo que ocasiona errores, pérdida de información y dificultades para administrar el negocio.

Con el desarrollo de un sistema de información se busca automatizar estos procesos, mejorar el control de las operaciones y facilitar la administración del supermercado mediante información organizada y confiable.

## Problema

La administración manual de las ventas, el inventario y las cuentas por cobrar dificulta el control de la información, genera errores en los registros, pérdidas económicas y retrasa la atención a los clientes.

## Objetivos

Automatizar el registro de ventas del supermercado.
Mejorar el control del inventario y del stock de productos.
Gestionar la información de clientes y cuentas por cobrar (fiados).
Administrar los usuarios del sistema según su rol.
Generar reportes que apoyen la toma de decisiones.
Optimizar los procesos administrativos y operativos del supermercado.

## Referencias

Documento SRS – Sistema de Gestión Supermercado La Esquina, versión 1.0.
SENA. Programa Análisis y Desarrollo de Software.
IEEE 830 – Especificación de Requisitos de Software (SRS).
