# product-backlog

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Product Backlog

| Prioridad | Historia de usuario |
|-----------|---------------------|
| Alta | Como administrador quiero registrar productos para mantener actualizado el inventario. |
| Alta | Como cajero quiero registrar ventas para controlar las transacciones realizadas. |
| Alta | Como administrador quiero administrar los clientes para llevar el control de sus compras. |
| Media | Como administrador quiero gestionar los fiados para controlar las cuentas por cobrar. |
| Media | Como usuario quiero consultar el inventario para conocer la disponibilidad de productos. |
| Baja | Como administrador quiero generar reportes para analizar las ventas y el inventario. |