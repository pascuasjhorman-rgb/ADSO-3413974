# roadmap

> Estado: 🔴 | Última actualización: 2026-06-16
> Autor: Por definir | Equipo: Por definir

## Roadmap

### Fase 1
- Registro de usuarios.
- Gestión de productos.
- Control de inventario.

### Fase 2
- Registro de ventas.
- Administración de clientes.
- Gestión de cuentas por cobrar.

### Fase 3
- Reportes de ventas.
- Reportes de inventario.
- Mejoras y optimización del sistema.