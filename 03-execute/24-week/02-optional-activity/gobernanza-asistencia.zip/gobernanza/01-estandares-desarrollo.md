# GOB-01: Estándares de Desarrollo y Seguridad
**Proyecto:** sena-asistencia (ficha ADSO 3413974) | **Entorno:** Python 3 / FastAPI / PostgreSQL  
**Última revisión:** 2026-09-18 | **Estado:** VIGENTE

---

## 1. Arquitectura Hexagonal del Backend (ADR-002)

### 1.1 Separación de Responsabilidades
| Capa | Responsabilidad | Prohibición |
| :--- | :--- | :--- |
| Dominio | Entidades y sus invariantes: `Aprendiz`, `Checkpoint`, `CodigoOTP`, `RegistroAsistencia`, `ModificacionRegistro` | Depender de FastAPI, del motor SQL o de cualquier librería externa |
| Aplicación | Casos de uso (`ValidarIdentidadAprendiz`, `RegistrarAsistencia`, `AbrirCheckpoint`, `ModificarAsistenciaManual`) y puertos | Importar implementaciones concretas; solo depende de puertos |
| Infraestructura | Rutas FastAPI, repositorios SQL, adaptador SSE | Contener reglas de negocio |

### 1.2 Puertos Obligatorios
`RepositorioAprendiz`, `RepositorioRegistroAsistencia`, `RelojUTC`, `NotificadorTiempoReal`.

**Regla:** un caso de uso resuelve **una sola** operación de negocio (SRP) y depende de interfaces, nunca de clases concretas (DIP).

---

## 2. Reglas de Validación en Servidor

### 2.1 Constantes de Negocio
Estos valores son fijos (SRS, sección 4) y viven en un único lugar del backend:

```python
OTP_VIGENCIA_SEGUNDOS = 20
OTP_TOLERANCIA_MS = 500
MAX_INTENTOS_FALLIDOS = 3
BLOQUEO_SEGUNDOS = 30
TIPOS_DOCUMENTO_VALIDOS = {"CC", "TI", "PEP", "CE"}
```

### 2.2 Reglas Obligatorias
- La vigencia del OTP se valida **siempre en el servidor**, nunca solo en el cliente.
- La base temporal es **UTC del reloj del servidor**; nunca se usa la hora del cliente.
- Tras 3 intentos fallidos consecutivos desde la misma IP y checkpoint, el dispositivo se bloquea 30 s (HTTP 429).
- La expiración natural del OTP **no** cuenta como intento fallido; solo los datos objetivamente incorrectos.

---

## 3. Contrato de la API (ADR-004: API-First)

El contrato se define en OpenAPI (YAML) **antes** de escribir código. Cambiar una ruta o payload exige actualizar el contrato.

| Ruta | Verbo | Propósito |
| :--- | :---: | :--- |
| `/api/validar-identidad` | POST | Valida documento y nombre contra la ficha activa |
| `/api/registrar-asistencia` | POST | Valida OTP y registra asistencia |
| `/api/checkpoint/abrir` | POST | Abre checkpoint (genera QR y OTP) |
| `/api/checkpoint/cerrar` | POST | Cierra checkpoint; marca `AUSENTE` a quien no se registró |
| `/api/checkpoint/realtime` | GET | Estado en tiempo real (SSE) |
| `/api/asistencia/modificar` | PUT | Registro manual con auditoría |

### Códigos HTTP documentados
| Código | Uso |
| :---: | :--- |
| 200 | Consulta o actualización exitosa |
| 201 | Recurso creado (apertura de checkpoint) |
| 400 | Payload inválido o tipo de documento no soportado |
| 401 | Identidad no coincide con la ficha, u OTP incorrecto/expirado |
| 404 | Checkpoint o ficha no encontrados o inactivos |
| 409 | Registro duplicado para el mismo checkpoint |
| 429 | Dispositivo bloqueado (3 intentos → 30 s) |

---

## 4. Interfaz del Aprendiz (WCAG 2.1 AA)

| Requisito | Regla |
| :--- | :--- |
| Diseño | Mobile-first; flujo limitado a 3 pantallas secuenciales |
| Fuente | Mínimo 16 px |
| Contraste | Alto entre texto y fondo |
| Estados (éxito, error, tarde) | Diferenciados por **texto e ícono**, nunca solo por color |
| Teclado | Foco visible en todos los controles interactivos |
| Errores | Mensajes claros y accionables |
