# GOB-02: Definition of Done (DoD)
**Última revisión:** 2026-09-18 | **Estado:** VIGENTE

Antes de dar por terminada una funcionalidad, el desarrollador debe confirmar:

---

## 1. Calidad de Código
- [ ] La lógica de negocio vive en Dominio/Aplicación, sin importar FastAPI ni el motor SQL (GOB-01 §1).
- [ ] Las constantes de negocio (OTP, bloqueo) no se duplican ni se hardcodean fuera de su lugar único.
- [ ] Los casos de uso nuevos tienen prueba con mocks de sus puertos.

## 2. Contrato y Datos
- [ ] Toda ruta nueva o modificada está definida en el contrato OpenAPI antes de implementarse (ADR-004).
- [ ] Todo cambio de esquema (incluido un nuevo valor de ENUM) tiene migración formal (ADR-003).
- [ ] Los códigos HTTP devueltos son los documentados en GOB-01 §3.

## 3. Funcional
- [ ] El flujo completo QR + OTP fue probado de extremo a extremo.
- [ ] El registro manual por el instructor fue verificado.
- [ ] Un registro duplicado devuelve 409 controlado.
- [ ] Tres intentos fallidos devuelven 429 y bloquean 30 s.

## 4. Seguridad y Cumplimiento
- [ ] La validación del OTP sigue ocurriendo en el servidor.
- [ ] Todo registro manual queda con el flag `editado` y una fila en `modificacion_registro`.
- [ ] Ningún dato personal se expone sin consentimiento de Habeas Data.

## 5. Accesibilidad (solo cambios en la interfaz del aprendiz)
- [ ] Cumple GOB-01 §4: fuente ≥ 16 px, contraste alto, estados con texto e ícono, foco visible.
