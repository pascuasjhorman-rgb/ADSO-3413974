# GOB-03: Criterios de Aceptación del Dominio (Asistencia)
**Última revisión:** 2026-09-18 | **Estado:** VIGENTE

Para garantizar la integridad de la asistencia, los módulos del SRS deben cumplir los siguientes criterios verificables.

---

## Módulo A: Identidad y Acceso del Aprendiz (RF-A1 a RF-A3)

| AC | Criterio | Verificación |
| :- | :--- | :--- |
| AC-A.1 | Solo se aceptan tipos de documento CC, TI, PEP y CE. | Enviar `tipo_documento` distinto → HTTP 400. |
| AC-A.2 | El par documento-nombre debe existir en la ficha activa. | Enviar nombre que no coincide → HTTP 401. |
| AC-A.3 | El consentimiento de Habeas Data se solicita en el primer acceso. | Primer ingreso → respuesta con `requiere_consentimiento: true`; tras aceptar, `consentimiento_fecha` queda registrada. |

## Módulo B: Validación Dual QR + OTP (RF-B1 a RF-B4, RF-D1)

| AC | Criterio | Verificación |
| :- | :--- | :--- |
| AC-B.1 | Un OTP vigente (≤ 20 s + 500 ms) registra la asistencia. | Enviar OTP actual → registro creado. |
| AC-B.2 | Un OTP incorrecto o expirado se rechaza en el servidor. | Enviar OTP viejo → HTTP 401 "Código OTP incorrecto o expirado". |
| AC-B.3 | La pantalla del aprendiz muestra un contador regresivo de 20 s. | Inspección visual del flujo. |
| AC-B.4 | Un segundo registro en el mismo checkpoint se rechaza. | Registrar dos veces → HTTP 409. |
| AC-B.5 | Tres intentos fallidos bloquean el dispositivo 30 s. | Fallar 3 veces → HTTP 429; reintento tras 30 s funciona. |
| AC-B.6 | La expiración natural del OTP no cuenta como intento fallido. | Enviar OTP recién expirado → 401 sin sumar al contador de bloqueo. |

## Módulo C: Gestión del Instructor (RF-C1 a RF-C5)

| AC | Criterio | Verificación |
| :- | :--- | :--- |
| AC-C.1 | Abrir un checkpoint genera el QR y la secuencia de OTP. | `POST /api/checkpoint/abrir` → devuelve `qr_token_estatico` y OTP. |
| AC-C.2 | Cerrar un checkpoint marca `AUSENTE` a quienes no se registraron. | Cerrar con aprendices sin registro → aparecen como `AUSENTE`. |
| AC-C.3 | El panel refleja la asistencia en tiempo real. | Registrar un aprendiz → el panel se actualiza sin recargar. |
| AC-C.4 | Todo registro manual lleva el flag "Editado" y auditoría. | `PUT /api/asistencia/modificar` → `editado = TRUE` y una fila en `modificacion_registro` con motivo. |
| AC-C.5 | El panel conserva el último estado si se pierde la conexión en tiempo real. | Cortar la conexión → el panel sigue mostrando el último estado. |
| AC-C.6 | Los listados de asistencia cargan en menos de 2 segundos. | Medir carga del listado de una ficha de 30 aprendices. |

## Módulo D: Seguridad y Cumplimiento (RF-D2 a RF-D4)

| AC | Criterio | Verificación |
| :- | :--- | :--- |
| AC-D.1 | Cada registro guarda IP, User-Agent y marca de tiempo UTC. | `SELECT ip_registro, user_agent, marca_tiempo_utc FROM registro_asistencia` → sin nulos. |
| AC-D.2 | Si una misma IP registra 3 o más aprendices distintos en un checkpoint, se emite alerta **pasiva**. | Registrar 3 aprendices desde una IP → alerta visible en el panel; ningún registro es bloqueado. |
| AC-D.3 | Seis meses después de `ficha.fecha_certificacion`, los datos identificables quedan anonimizados. | Tras el job: `anonimizado = TRUE` y documento/nombre reemplazados. |

## Módulo E: Contingencias (Plan de Contingencia)

| Situación | Respuesta del instructor | Motivo (`motivo_manual_enum`) |
| :--- | :--- | :---: |
| Aprendiz sin celular | Registro manual desde el panel | `SIN_CELULAR` |
| Discapacidad (visual, motriz) | Registro manual inmediato | `DISCAPACIDAD` |
| QR no escanea o no se proyecta | Compartir enlace con `?checkpoint=ID`; si persiste, registro manual | `FALLA_RED` u `OTRO` |
| Pérdida de conectividad en el aula | Registro manual de toda la ficha | `FALLA_RED` |
| Alerta de IP duplicada | Revisar y, si procede, invalidar por edición manual | `OTRO` |
| Bloqueo injustificado | Registro manual sin esperar el desbloqueo | `OTRO` |

Todo registro manual exige justificación y queda auditado (AC-C.4).
