# GOB-06: Entorno de Ejecución y Despliegue
**Última revisión:** 2026-09-18 | **Estado:** VIGENTE

---

## 1. Requisitos de Infraestructura

| Componente | Requisito Mínimo | Configuración Recomendada |
| :--- | :--- | :--- |
| **Backend** | Python 3 con `fastapi==0.115.0`, `uvicorn==0.30.6`, `pydantic==2.9.2`, `jinja2==3.1.4` | Instalar con `pip install -r Backend/requirements.txt` |
| **Base de Datos** | PostgreSQL (ENUM y `TIMESTAMPTZ`) | Cargar `Base de datos/esquema.sql` |
| **Frontend** | Navegador web (HTML/CSS/JS nativo) | `API_BASE` configurable con `window.API_BASE` |
| **Red** | LAN del aula/sede, **sin dependencia de internet** | Requisito crítico: una caída de internet no debe interrumpir la asistencia |
| **Reloj** | Servidor sincronizado por NTP | Base de tiempo en UTC |

> **Estado actual:** `main.py` guarda los datos **en memoria** con la estructura del esquema SQL; se pierden al reiniciar. Para producción cada repositorio debe pasar a consultas PostgreSQL (ADR-002 y ADR-003).

---

## 2. Arranque

```bash
cd Backend
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

El frontend apunta por defecto a `http://localhost:8000` (`API_BASE` en `Frontend/app.js`). Para usarlo desde otros equipos de la LAN, definir `window.API_BASE` con la dirección del servidor.

Vistas: `Frontend/index.html` (aprendiz) y `Frontend/instructor.html` (panel del instructor).

---

## 3. Verificación del Servicio

`GET /api/salud` devuelve el estado y la hora UTC del servidor:

```json
{"estado": "ok", "hora_servidor_utc": "2026-09-18T18:00:00+00:00"}
```

---

## 4. Guía de Solución de Problemas (Troubleshooting)

| Síntoma / Error | Causa Raíz | Solución Operativa |
| :--- | :--- | :--- |
| **OTP siempre "incorrecto o expirado"** (401) | Desfase entre el reloj del servidor y la hora real | Comparar `hora_servidor_utc` de `/api/salud` con la hora real y sincronizar NTP. |
| **401 con OTP recién visto** | Expiración natural (20 s) | Comportamiento normal: reingresar el código vigente; no cuenta como intento fallido. |
| **429 al registrar** | 3 intentos fallidos desde la misma IP | Esperar los segundos indicados; si es injustificado, el instructor registra manualmente. |
| **409 al registrar** | Registro duplicado en el checkpoint | Comportamiento normal controlado por `UNIQUE (id_aprendiz, id_checkpoint)`. |
| **El frontend no conecta con la API** | `API_BASE` apunta a `localhost` desde otro equipo, o el backend está apagado | Definir `window.API_BASE` con la IP del servidor y verificar `/api/salud`. |
| **Datos desaparecen tras reiniciar** | Persistencia en memoria (prototipo) | Migrar los repositorios a PostgreSQL (ver nota del §1). |
