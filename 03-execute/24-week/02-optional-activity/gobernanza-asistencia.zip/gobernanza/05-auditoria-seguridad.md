# GOB-05: Matriz de Seguridad y Vectores de Ataque
**Última revisión:** 2026-09-18 | **Estado:** VIGENTE

> El estado de cada riesgo se contrastó con `Backend/main.py` y `Base de datos/esquema.sql`, no solo con los ADR.

---

## 1. Matriz de Riesgos

| ID | Vector | Severidad | Estado | Mitigación |
| :- | :--- | :---: | :---: | :--- |
| SEC-01 | Registro remoto / reenvío de QR u OTP | 🟠 Alta | ⚠️ Parcial | QR estático + OTP de 20 s validado en servidor con hora UTC. El OTP se genera con `random`, no con TOTP (RFC 6238) como exige ADR-001 v2. |
| SEC-02 | Fuerza bruta sobre el OTP | 🟠 Alta | ✅ Mitigado | Bloqueo de 30 s tras 3 fallos por IP + checkpoint (HTTP 429). |
| SEC-03 | Registro duplicado / concurrencia | 🟡 Media | ✅ Mitigado | `UNIQUE (id_aprendiz, id_checkpoint)` en BD y HTTP 409 en la API. |
| SEC-04 | Varios aprendices desde una misma IP | 🟡 Media | ✅ Mitigado | Alerta pasiva al llegar a 3 aprendices; no bloquea (Wi-Fi de aula compartida es normal). |
| SEC-05 | Manipulación de asistencia por edición manual | 🟠 Alta | ✅ Mitigado | Flag `editado` + fila obligatoria en `modificacion_registro`. |
| SEC-06 | Acceso sin autenticación a rutas del instructor | 🔴 Crítica | ❌ Pendiente | Las rutas de checkpoint y `/api/asistencia/modificar` no exigen login; `id_instructor` llega en el payload (valor por defecto `1`). |
| SEC-07 | Exposición de datos personales | 🔴 Crítica | ❌ Pendiente | ADR-001 exige cifrado de columnas y job de anonimización; el esquema guarda `numero_documento` y `nombre_completo` en texto plano y no existe el job. |
| SEC-08 | CORS abierto | 🟡 Media | ❌ Pendiente | `allow_origins=["*"]` en `main.py`. |
| SEC-09 | Desfase de reloj del servidor | 🟡 Media | ⚠️ Parcial | Hora UTC del servidor y tolerancia de 500 ms; requiere sincronización NTP. |

---

## 2. Plan de Mitigación para Riesgos Pendientes

### SEC-06 — Autenticación del instructor
**Acción requerida:** proteger las rutas del instructor con autenticación (la tabla `instructor` ya tiene `hash_password`) y obtener `id_instructor` de la sesión, nunca del payload.

### SEC-07 — Protección de datos personales
**Acción requerida:** cifrar `numero_documento` y `nombre_completo` a nivel de columna e implementar el job de anonimización a 6 meses de `fecha_certificacion` (GOB-04 §5).

### SEC-08 — CORS
**Acción requerida:** limitar `allow_origins` al origen del frontend dentro de la LAN.

### SEC-01 — Generación del OTP
**Acción requerida:** generar el OTP con TOTP (RFC 6238) y semilla propia por checkpoint, según ADR-001 v2.

### SEC-09 — Reloj del servidor
**Acción requerida:** mantener el servidor sincronizado por NTP; verificar con `/api/salud` (GOB-06 §4).
