# GOB-04: Arquitectura de Datos y PostgreSQL
**Última revisión:** 2026-09-18 | **Estado:** VIGENTE

---

## 1. Esquema Actual del Proyecto (Referencia)

```
instructor ───────────────────────────────────────────────
  id_instructor | numero_documento (UNIQUE) | tipo_documento
  nombre_completo | correo (UNIQUE) | hash_password | creado_en

ficha ────────────────────────────────────────────────────
  id_ficha | codigo_ficha (UNIQUE) | programa
  id_instructor → instructor | fecha_certificacion | activa

aprendiz ─────────────────────────────────────────────────
  id_aprendiz | numero_documento | tipo_documento | nombre_completo
  id_ficha → ficha | consentimiento_habeas_data | consentimiento_fecha
  anonimizado | UNIQUE (numero_documento, id_ficha)

checkpoint ───────────────────────────────────────────────
  id_checkpoint | id_ficha → ficha | tipo_checkpoint
  qr_token_estatico (UNIQUE) | abierto_en | cerrado_en | activo

codigo_verificacion ──────────────────────────────────────
  id_codigo | id_checkpoint → checkpoint | codigo_otp CHAR(6)
  valido_desde_utc | valido_hasta_utc (CHECK hasta > desde)

registro_asistencia ──────────────────────────────────────
  id_registro | id_aprendiz → aprendiz | id_checkpoint → checkpoint
  estado | origen | editado | ip_registro | user_agent | marca_tiempo_utc
  UNIQUE (id_aprendiz, id_checkpoint)

modificacion_registro ────────────────────────────────────
  id_modificacion | id_registro → registro_asistencia
  id_instructor → instructor | estado_anterior | estado_nuevo
  motivo | justificacion_texto | modificado_en_utc

intento_pendiente ────────────────────────────────────────
  id_intento | ip_origen | id_checkpoint → checkpoint
  intentos_fallidos | bloqueado_hasta_utc | actualizado_en_utc
  UNIQUE (ip_origen, id_checkpoint)
```

---

## 2. Integridad Relacional (ADR-003)

### 2.1 Tipos Estrictos (Obligatorio)
El motor rechaza valores fuera de dominio mediante tipos `ENUM`:

| ENUM | Valores |
| :--- | :--- |
| `tipo_documento_enum` | `CC`, `TI`, `PEP`, `CE` |
| `tipo_checkpoint_enum` | `INICIO`, `RECESO`, `FIN` |
| `estado_asistencia_enum` | `ASISTIO`, `TARDE`, `AUSENTE` |
| `origen_registro_enum` | `AUTOMATICO`, `MANUAL` |
| `motivo_manual_enum` | `SIN_CELULAR`, `DISCAPACIDAD`, `FALLA_RED`, `OTRO` |

Las fechas usan `TIMESTAMP WITH TIME ZONE` y se manejan en **UTC**.

### 2.2 Política de Borrado
| Entidad | Política | Razón |
| :--- | :--- | :--- |
| `ficha` | Desactivación (`activa = FALSE`) | Preservar relaciones con aprendices |
| `checkpoint` | Cierre (`activo = FALSE`, `cerrado_en`) | Preservar registros asociados |
| `aprendiz` | Anonimización (`anonimizado = TRUE`), no borrado | Conservar estadísticas sin identidad |
| `registro_asistencia`, `modificacion_registro` | No se borran | Son evidencia de asistencia y auditoría |

**Regla:** las llaves foráneas no usan `ON DELETE CASCADE`. Un registro no puede existir sin su aprendiz y checkpoint, ni una auditoría sin su registro.

---

## 3. Índices y Rendimiento

### 3.1 Índices Actuales
| Tabla | Columna(s) | Propósito |
| :--- | :--- | :--- |
| `aprendiz` | `(numero_documento, nombre_completo)` | Validación de identidad |
| `aprendiz` | `id_ficha` | Listado de la ficha |
| `ficha` | `activa` | Filtro de ficha activa |
| `checkpoint` | `(id_ficha, activo)` | Checkpoint vigente de una ficha |
| `codigo_verificacion` | `(id_checkpoint, valido_desde_utc, valido_hasta_utc)` | Búsqueda del OTP vigente |
| `registro_asistencia` | `id_checkpoint` | Listado por checkpoint |
| `registro_asistencia` | `(ip_registro, id_checkpoint)` | Alerta de duplicidad por IP |
| `modificacion_registro` | `id_registro` | Historial de un registro |
| `intento_pendiente` | `ip_origen` | Control de bloqueo |

### 3.2 Regla para Nuevas Columnas
Toda columna usada con frecuencia en `WHERE`, `JOIN ON` u `ORDER BY` debe tener un índice definido junto al esquema. Meta: listados de asistencia en **menos de 2 segundos**.

---

## 4. Auditoría y Trazabilidad

- Cada `registro_asistencia` guarda de forma **inmutable**: IP, User-Agent y `marca_tiempo_utc`.
- Toda edición manual crea una fila en `modificacion_registro` (estado anterior y nuevo, instructor, motivo, justificación) y activa el flag `editado`.
- Un cambio de esquema, incluido añadir un valor a un ENUM, requiere una **migración formal y versionada** (ADR-003).

---

## 5. Ciclo de Vida de Datos Personales (Ley 1581 de 2012)

| Etapa | Regla |
| :--- | :--- |
| Consentimiento | Se pide en el primer acceso; se guarda `consentimiento_habeas_data` y `consentimiento_fecha`. Sin él no se completa el registro. |
| Cifrado | `numero_documento` y `nombre_completo` cifrados en reposo (columna); el backend descifra solo en memoria. |
| Retención | Mientras la ficha esté activa y hasta 6 meses después de `ficha.fecha_certificacion`. |
| Anonimización | Un job programado reemplaza documento y nombre (hash irreversible o `ANONIMIZADO`) y marca `anonimizado = TRUE`. Solo quedan datos agregados. |
| Auditoría | `modificacion_registro` se conserva como evidencia y también se anonimiza pasado el período, salvo obligación legal distinta. |
